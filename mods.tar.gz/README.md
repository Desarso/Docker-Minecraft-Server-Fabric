# Mods Folder

Place your Fabric mod `.jar` files in this folder.

## How to use:

1. Download Fabric mods from [Modrinth](https://modrinth.com/) or [CurseForge](https://www.curseforge.com/minecraft/mc-mods)
2. Make sure the mods are compatible with **Minecraft 1.21.6** and **Fabric**
3. Place the `.jar` files directly in this `mods/` folder
4. Run `make compress` to create `mods.tar.gz`
5. Upload `mods.tar.gz` to your server/repository and set the `MODS_BACKUP` environment variable to the URL

## Popular Fabric Mods for 1.21.6:

- **Fabric API** - Required by most mods
- **Lithium** - Performance optimization
- **Sodium** - Client-side rendering optimization
- **Phosphor** - Lighting engine optimization

## Example:
```bash
# Add your mods to this folder
cp ~/Downloads/fabric-api-*.jar mods/
cp ~/Downloads/lithium-*.jar mods/

# Compress for deployment
make compress

# This creates mods.tar.gz ready for use with MODS_BACKUP
``` 